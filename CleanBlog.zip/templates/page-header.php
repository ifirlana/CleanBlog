<?php use Roots\Sage\Titles; ?>
<div class="container">
	<div class="row">
		<div class="col-lg-8 col-lg-offset-2 col-md-10 col-md-offset-1">
			<h1><?= Titles\title(); ?></h1>
		</div>
	</div>
</div>